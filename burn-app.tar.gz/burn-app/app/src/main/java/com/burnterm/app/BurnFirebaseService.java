package com.burnterm.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class BurnFirebaseService extends FirebaseMessagingService {

    private static final String TAG = "BURNTerminal";

    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "═══════════════════════════════════════");
        Log.d(TAG, "NEW FCM TOKEN:");
        Log.d(TAG, token);
        Log.d(TAG, "═══════════════════════════════════════");
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        Log.d(TAG, "Push received from: " + message.getFrom());

        String title = "BURN Terminal";
        String body = "Alert triggered";
        String tag = "burn-alert";

        // Data message (from our server)
        if (message.getData().size() > 0) {
            title = message.getData().getOrDefault("title", title);
            body = message.getData().getOrDefault("body", body);
            tag = message.getData().getOrDefault("tag", tag);
        }

        // Notification message (from Firebase console)
        if (message.getNotification() != null) {
            title = message.getNotification().getTitle() != null ?
                    message.getNotification().getTitle() : title;
            body = message.getNotification().getBody() != null ?
                    message.getNotification().getBody() : body;
        }

        showNotification(title, body, tag);
    }

    private void showNotification(String title, String body, String tag) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "burn_alerts")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .setVibrate(new long[]{0, 200, 100, 200})
                .setContentIntent(pendingIntent)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body));

        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Create channel for Android 8+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "burn_alerts", "BURN Alerts", NotificationManager.IMPORTANCE_HIGH);
            manager.createNotificationChannel(channel);
        }

        manager.notify(tag.hashCode(), builder.build());
    }
}
