#!/bin/bash
# ═══ BURN Terminal APK Builder ═══
# Run this on Hetzner or any Linux with Java 17+

set -e

echo "═══ BURN Terminal APK Builder ═══"

# 1. Check Java
if ! command -v java &> /dev/null; then
    echo "Installing Java 17..."
    sudo apt update && sudo apt install -y openjdk-17-jdk
fi
echo "Java: $(java -version 2>&1 | head -1)"

# 2. Check Android SDK
ANDROID_HOME=${ANDROID_HOME:-$HOME/android-sdk}
if [ ! -d "$ANDROID_HOME/platforms" ]; then
    echo "Installing Android SDK..."
    mkdir -p $ANDROID_HOME
    cd /tmp
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-10406996_latest.zip
    unzip -q commandlinetools-linux-10406996_latest.zip
    mkdir -p $ANDROID_HOME/cmdline-tools
    mv cmdline-tools $ANDROID_HOME/cmdline-tools/latest
    yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses 2>/dev/null || true
    $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
fi
export ANDROID_HOME
export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
echo "Android SDK: $ANDROID_HOME"

# 3. Check google-services.json
if [ ! -f "app/google-services.json" ]; then
    echo ""
    echo "⚠️  google-services.json FEHLT!"
    echo ""
    echo "So bekommst du es:"
    echo "1. Gehe zu https://console.firebase.google.com"
    echo "2. 'Projekt hinzufügen' → Name: BURN Terminal"
    echo "3. Android-App hinzufügen → Package: com.burnterm.app"
    echo "4. google-services.json herunterladen"
    echo "5. In burn-app/app/ ablegen"
    echo "6. Dieses Script nochmal starten"
    echo ""
    exit 1
fi

# 4. Build
echo "Building APK..."
chmod +x gradlew 2>/dev/null || true
if [ ! -f "gradlew" ]; then
    gradle wrapper --gradle-version 8.3 2>/dev/null || {
        echo "Downloading Gradle wrapper..."
        wget -q https://services.gradle.org/distributions/gradle-8.3-bin.zip -O /tmp/gradle.zip
        unzip -q /tmp/gradle.zip -d /tmp
        /tmp/gradle-8.3/bin/gradle wrapper --gradle-version 8.3
    }
fi
./gradlew assembleDebug

# 5. Done
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "═══ APK FERTIG ═══"
    echo "Datei: $APK_PATH"
    echo "Größe: $(du -h $APK_PATH | cut -f1)"
    echo ""
    echo "Auf Handy übertragen:"
    echo "  scp $APK_PATH noah@handy:/sdcard/Download/"
    echo "  Oder: Download-Link erstellen mit python3 -m http.server"
    echo ""
else
    echo "Build fehlgeschlagen. Prüfe Fehler oben."
fi
